
void test2(int &x, int &y) {
  if (1) {
    x = 1;
    y = 1;
  }
  else {
    x = 5;
    y = 5.0;
  }
}
