
void test1(int &x) {
  x = 100 + (1 + 1) * 5 / 10;  
}
